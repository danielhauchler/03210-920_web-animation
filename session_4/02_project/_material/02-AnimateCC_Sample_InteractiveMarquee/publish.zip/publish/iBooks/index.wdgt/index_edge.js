
(function(compId){var _=null,y=true,n=false,x23='glow',e12='${overlay}',x2='5.0.1',e15='${Loop}',e11='${f2}',e130='${glow5}',x93='22px',x56='img_0002_f2',d='display',x63='230px',x53='glow2',x86='Rectangle2',x58='hover_0003_f2_2',x64='rgba(255,255,255,0.89)',x36='rgba(0,0,0,0.51)',e50='${hover_0004_m1_1}',e51='${hover_0002_f2_12}',e125='${img_0004_f1}',e115='${glow3}',xc='rgba(0,0,0,1)',x40='hover_0002_f2_12',x127='22',e114='${img_0003_m1}',rz='rotateZ',e34='${img_0001_m2}',e47='${hover_0000_f1_1}',e60='${glow2}',x81='316px',x28='1',x24='0',x67='10px',e46='${clickarea}',x4='5.0.1.386',p='px',o='opacity',x88='rgba(255,255,255,0.48)',x42='hover_0000_f1_1',x30='hover_0007_m2_2',e62='${img_0002_f2}',x116='-20',e49='${content}',e16='${m1}',x76='334px',e32='${hover_0007_m2_2}',e48='${hover_0007_m2_22}',e61='${hover_0003_f2_2}',x94='Text3',x80='700',x82='89px',x99='71px',x108='img_0003_m1',x83='Text2',e124='${hover_0001_f1_2}',e103='${Group}',x97='rgba(255,255,255,1.00)',x37='content',e33='${glow}',lf='left',x44='hover_0004_m1_1',x92='86px',x77='50px',x91='rgba(0,0,0,0.45)',bg='background-color',x18='193px',x20='auto',x79='rgba(227,0,0,1.00)',tp='top',x3='5.0.0',x100='100px',e126='${glow4}',x122='hover_0001_f1_2',x121='3',x54='191px',x118='295px',x72='Group',x5='rgba(0,0,0,0)',x117='glow4',e113='${hover_0005_m1_2}',g='image',po='center',x110='-2',x55='289px',x65='Rectangle',x106='-10',b='block',x66='5px',x107='glow3',e105='${Rectangle}',e104='${Group2}',x='text',e14='${img_0005_snipes}',x87='3px',m='rect',x26='0px',x101='closeButton',x111='hover_0005_m1_2',e13='${m2}',x128='glow5',x35='clickarea',x98='Group2',x71='50',x73='group',i='none',x96='-1px',x90='30px',x89='rgba(63,63,63,1.00)',x129='0.15',x22='50%',x78='Arial, Helvetica, sans-serif',x27='img_0001_m2',l='normal',x119='img_0004_f1',x68='rgba(0,0,0,0.32)',x74='Text',x70='334',w='width',e17='${f1}',x19='463px',x38='hover_0007_m2_22',x85='rgba(59,59,59,1.00)',x21='20',x69='34px',x10='rgba(0,0,0,1.00)',x52='10';var g102='closeButton.png',g57='img_0002_f2.png',g7='img_0005_logo.png',g8='img_0000_footer.png',g39='hover_0006_m2_1.png',g6='img_0006_bg.png',g25='glow.png',g1='jquery-1.7.1.min.js',g59='hover_0003_f2_2.png',g9='Loop.png',g123='hover_0001_f1_2.png',g120='img_0004_f1.png',g45='hover_0004_m1_1.png',g31='hover_0007_m2_2.png',g109='img_0003_m1.png',g29='img_0001_m2.png',g41='hover_0002_f2_1.png',g43='hover_0000_f1_1.png',g112='hover_0005_m1_2.png';var s75="My Product",s84="Description",s95="Buy now";var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[js+g1],symbols={"stage":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{id:'Background',t:g,r:['0','0','940px','360','auto','auto'],f:[x5,im+g6,'0px','0px']},{id:'Spotlight',symbolName:'spotlight',t:m,r:['-353','-78','352','502','auto','auto']},{id:'img_0005_snipes',t:g,r:['560','-129','380px','129px','auto','auto'],f:[x5,im+g7,'0px','0px']},{id:'m2',symbolName:'m2',t:m,r:['1015','51','164','288','auto','auto'],cu:'pointer'},{id:'f2',symbolName:'f2',t:m,r:['988','50','191','289','auto','auto'],cu:'pointer'},{id:'m1',symbolName:'m1',t:m,r:['-261','50','191','289','auto','auto'],cu:'pointer'},{id:'f1',symbolName:'f1',t:m,r:['-252','50','191','295','auto','auto'],cu:'pointer'},{id:'overlay',symbolName:'overlay',v:i,t:m,r:['0','0','940','340','auto','auto'],cu:'pointer'},{id:'Floor',t:g,r:['0','289','940px','70px','auto','auto'],f:[x5,im+g8,'0px','0px']},{id:'Loop',t:g,r:['10','324','24px','24px','auto','auto'],cu:'pointer',o:'0',f:[x5,im+g9,'0px','0px']}],style:{'${Stage}':{isStage:true,r:['null','null','940','360','auto','auto'],overflow:'hidden',f:[x10]}}},tt:{d:6000,a:y,l:{"overview":4037,"overlay":4370},data:[["eid176",lf,2132,1438,"easeOutExpo",e11,'988px','462px'],["eid51",d,4370,0,"linear",e12,i,b],["eid178",lf,1716,1093,"easeOutExpo",e13,'1015px','682px'],["eid180",tp,3034,635,"easeOutBounce",e14,'-129px','0px'],["eid238",o,3293,744,"linear",e15,'0','1'],["eid174",lf,1716,1577,"easeOutExpo",e16,'-261px','284px'],["eid172",lf,1559,1093,"easeOutExpo",e17,'-252px','72px']]}},"m2":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[-8,-108,x18,x19,x20,x20],tf:[[0,0,0],[x21,0,0],[0,0],[1,1,1],[x22,x22]],id:x23,o:x24,t:g,f:[x5,im+g25,x26,x26]},{r:[0,0,191,288,x20,x20],id:x27,o:x28,t:g,f:[x5,im+g29,x26,x26]},{r:[-7,-56,170,399,x20,x20],t:g,id:x30,o:x24,v:i,f:[x5,im+g31,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,164,288]}}},tt:{d:733.33333333333,a:n,l:{"over":0,"over_end":666},data:[["eid113",d,467,0,"linear",e32,i,b],["eid194",o,0,400,"easeOutExpo",e33,'0','0.4912025'],["eid116",o,400,133,"linear",e34,'1','0'],["eid114",o,467,133,"linear",e32,'0','1']]}},"overlay":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{t:m,o:x24,id:x35,s:[0,xc,i],r:[0,0,940,340,x20,x20],f:[x36]},{r:[298,55,400,230,x20,x20],id:x37,sN:x37,t:m},{t:g,r:[653,-34,254,596,x20,x20],v:i,o:x24,id:x38,f:[x5,im+g39,x26,x26]},{t:g,r:[403,-12,284,572,x20,x20],v:i,o:x24,id:x40,f:[x5,im+g41,x26,x26]},{t:g,r:[41,-19,244,534,x20,x20],v:i,o:x24,id:x42,f:[x5,im+g43,x26,x26]},{t:g,r:[212,-9,290,506,x20,x20],v:i,o:x24,id:x44,f:[x5,im+g45,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,940,340]}}},tt:{d:2933,a:n,l:{"inactive":0,"m2":533,"f2":1200,"f1":1933,"m1":2600},data:[["eid64",bg,1467,0,"linear",e46,'rgba(0,0,0,0.51)','rgba(0,0,0,0.51)'],["eid140",bg,2199,0,"linear",e46,'rgba(0,0,0,0.51)','rgba(0,0,0,0.51)'],["eid143",bg,2867,0,"linear",e46,'rgba(0,0,0,0.51)','rgba(0,0,0,0.51)'],["eid135",o,1933,266,"linear",e47,'0','1'],["eid27",d,533,0,"linear",e48,i,b],["eid54",d,867,0,"linear",e48,b,i],["eid133",d,1933,0,"linear",e47,i,b],["eid134",d,2266,0,"linear",e47,b,i],["eid84",lf,792,0,"easeOutBack",e49,'298px','298px'],["eid86",lf,1459,0,"easeOutBack",e49,'298px','102px'],["eid139",lf,2199,0,"easeOutBack",e49,'102px','224px'],["eid142",lf,2859,0,"easeOutBack",e49,'234px','428px'],["eid29",o,533,267,"linear",e48,'0','1'],["eid136",d,2600,0,"linear",e50,i,b],["eid137",d,2933,0,"linear",e50,b,i],["eid138",o,2600,267,"linear",e50,'0','1'],["eid43",d,1200,0,"linear",e51,i,b],["eid61",d,1533,0,"linear",e51,b,i],["eid62",o,533,267,"linear",e46,'0','1'],["eid63",o,1200,267,"linear",e46,'0','1'],["eid141",o,1933,266,"linear",e46,'0','1'],["eid144",o,2600,267,"linear",e46,'0','1'],["eid44",o,1200,267,"linear",e51,'0','1']]}},"f2":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[11,-81,x18,x19,x20,x20],tf:[[0,0,0],[x52,0,0],[0,0],[1,1,1],[x22,x22]],id:x53,o:x24,t:g,f:[x5,im+g25,x26,x26]},{r:[0,0,x54,x55,x20,x20],id:x56,o:x28,t:g,f:[x5,im+g57,x26,x26]},{r:[5,-36,174,345,x20,x20],t:g,id:x58,o:x24,v:i,f:[x5,im+g59,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,191,289]}}},tt:{d:733.33333333333,a:n,l:{"over":0,"over_end":666},data:[["eid202",o,0,400,"easeOutExpo",e60,'0','0.4912025'],["eid40",d,467,0,"linear",e61,i,b],["eid41",o,467,133,"linear",e61,'0','1'],["eid42",o,400,133,"linear",e62,'1','0']]}},"content":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[393,0,7,x63,x20,x20],o:x24,f:[x64],id:x65,s:[0,xc,i],t:m,boxShadow:['',x66,x66,x67,0,x68]},{r:[167,x69,x70,x71,x20,x20],id:x72,o:x24,t:x73,c:[{t:x,id:x74,text:s75,r:[0,0,x76,x77,x20,x20],n:[x78,[24,''],x79,x80,i,'','','']},{t:x,r:[0,43,x81,x82,x20,x20],id:x83,text:s84,align:lf,n:[x78,[12,p],x85,l,i,l,'','']},{t:m,id:x86,s:[x87,x88,i],r:[203,137,117,39,x20,x20],f:[x89],boxShadow:['',x26,x26,x90,x26,x91],c:[{t:x,r:[17,12,x92,x93,x20,x20],align:po,id:x94,text:s95,textShadow:[x10,x96,x96,x26],n:[x78,[14,p],x97,x80,i,l,'','']}]}]},{t:x73,v:i,id:x98,r:[-71,-24,x99,x100,x20,x20],c:[{r:[4,13,x90,x90,x20,x20],id:x101,t:g,f:[x5,im+g102,x26,x26]}]}],style:{'${symbolSelector}':{r:[_,_,400,230]}}},tt:{d:2533,a:n,l:{"start":0,"fadeRight":267,"fadeLeft":2000},data:[["eid82",lf,533,267,"easeOutBack",e103,'167px','-18px'],["eid104",lf,2266,267,"easeOutBack",e103,'-18px','100px'],["eid162",o,267,0,"easeOutBack",e103,'0','0'],["eid158",o,533,267,"easeOutBack",e103,'0','1'],["eid155",o,800,0,"easeOutBack",e103,'0','1'],["eid165",o,2000,0,"easeOutBack",e103,'1','0'],["eid105",o,2266,267,"easeOutBack",e103,'0','1'],["eid234",lf,800,0,"easeOutExpo",e104,'-71px','-71px'],["eid230",lf,2533,0,"easeOutExpo",e104,'-71px','442px'],["eid233",d,800,0,"easeOutExpo",e104,i,b],["eid236",d,2000,0,"easeOutExpo",e104,b,i],["eid232",d,2533,0,"easeOutExpo",e104,i,b],["eid103",w,267,466,"easeOutBack",e105,'7px','456px'],["eid108",w,2000,466,"easeOutBack",e105,'10px','462px'],["eid102",lf,267,466,"easeOutBack",e105,'393px','-56px'],["eid170",lf,2000,0,"easeOutBack",e105,'-56px','-1px'],["eid235",tp,800,0,"easeOutExpo",e104,'-24px','-24px'],["eid231",tp,2533,0,"easeOutExpo",e104,'-24px','-26px'],["eid78",o,267,467,"easeOutBack",e105,'0','1'],["eid106",o,2000,467,"easeOutBack",e105,'0','1']]}},"m1":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[-10,-78,x18,x19,x20,x20],tf:[[0,0,0],[x106,0,0],[0,0],[1,1,1],[x22,x22]],id:x107,o:x24,t:g,f:[x5,im+g25,x26,x26]},{r:[0,0,x54,x55,x20,x20],id:x108,o:x28,t:g,f:[x5,im+g109,x26,x26]},{t:g,r:[-10,-36,174,355,x20,x20],tf:[[0,0,0],[x110,0,0],[0,0],[1,1,1],[x22,x22]],v:i,o:x24,id:x111,f:[x5,im+g112,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,191,289]}}},tt:{d:733.33333333333,a:n,l:{"over":0,"over_end":666},data:[["eid203",d,467,0,"linear",e113,i,b],["eid204",o,467,133,"linear",e113,'0','1'],["eid205",o,400,133,"linear",e114,'1','0'],["eid206",o,0,400,"easeOutExpo",e115,'0','0.4912025']]}},"f1":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[1,-100,x18,x19,x20,x20],tf:[[0,0,0],[x116,0,0],[0,0],[1,1,1],[x22,x22]],id:x117,o:x24,t:g,f:[x5,im+g25,x26,x26]},{r:[0,0,x54,x118,x20,x20],id:x119,o:x28,t:g,f:[x5,im+g120,x26,x26]},{t:g,r:[14,-36,165,362,x20,x20],tf:[[0,0,0],[x121,0,0],[0,0],[1,1,1],[x22,x22]],v:i,o:x24,id:x122,f:[x5,im+g123,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,191,295]}}},tt:{d:733.33333333333,a:n,l:{"over":0,"over_end":666},data:[["eid207",d,467,0,"linear",e124,i,b],["eid208",o,467,133,"linear",e124,'0','1'],["eid209",o,400,133,"linear",e125,'1','0'],["eid210",o,0,400,"easeOutExpo",e126,'0','0.4912025']]}},"spotlight":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{t:g,tf:[[0,0,0],[x127,0,0],[0,0],[1,1,1],[x22,x22]],id:x128,o:x129,r:[-741,9,431,x19,x20,x20],f:[x5,im+g25,x26,x26]}],style:{'${symbolSelector}':{r:[_,_,352,502]}}},tt:{d:6000,a:y,data:[["eid227",rz,1503,3329,"easeOutExpo",e130,'22deg','-22deg'],["eid229",lf,0,1503,"easeOutExpo",e130,'-741px','-324px'],["eid226",lf,1503,3329,"easeOutExpo",e130,'-324px','1388px']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-11294651");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${m2}","mouseenter",function(sym,e){var currentSym=sym.getSymbol("m2");currentSym.play('over');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${m2}","click",function(sym,e){var overlay=sym.getSymbol("overlay");overlay.play('m2');sym.stop('overlay');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${m2}","mouseleave",function(sym,e){var currentSym=sym.getSymbol("m2");currentSym.playReverse();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${overlay}","click",function(sym,e){var overlay=sym.getSymbol("overlay");overlay.stop('inactive');sym.stop('overview');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f2}","click",function(sym,e){var overlay=sym.getSymbol("overlay");overlay.play('f2');sym.stop('overlay');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f2}","mouseenter",function(sym,e){var currentSym=sym.getSymbol("f2");currentSym.play('over');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f2}","mouseleave",function(sym,e){var currentSym=sym.getSymbol("f2");currentSym.playReverse();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",4037,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.getSymbolElement().css({margin:'auto'});});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f1}","click",function(sym,e){var overlay=sym.getSymbol("overlay");overlay.play('f1');sym.stop('overlay');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f1}","mouseenter",function(sym,e){var currentSym=sym.getSymbol("f1");currentSym.play('over');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${f1}","mouseleave",function(sym,e){var currentSym=sym.getSymbol("f1");currentSym.playReverse();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${m1}","click",function(sym,e){var overlay=sym.getSymbol("overlay");overlay.play('m1');sym.stop('overlay');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${m1}","mouseenter",function(sym,e){var currentSym=sym.getSymbol("m1");currentSym.play('over');});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${m1}","mouseleave",function(sym,e){var currentSym=sym.getSymbol("m1");currentSym.playReverse();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Loop}","click",function(sym,e){sym.play(0);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'm2'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",733,function(sym,e){sym.stop();});
//Edge binding end
})("m2");
//Edge symbol end:'m2'

//=========================================================

//Edge symbol: 'overlay'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",800,function(sym,e){sym.stop();sym.getSymbol("content").play('fadeRight');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1467,function(sym,e){sym.stop();sym.getSymbol("content").play('fadeRight');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",533,function(sym,e){sym.getSymbol("content").stop('start');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1200,function(sym,e){sym.getSymbol("content").stop('start');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1933,function(sym,e){sym.getSymbol("content").stop('start');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2199,function(sym,e){sym.stop();sym.getSymbol("content").play('fadeLeft');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2600,function(sym,e){sym.getSymbol("content").stop('start');});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2867,function(sym,e){sym.stop();sym.getSymbol("content").play('fadeLeft');});
//Edge binding end
})("overlay");
//Edge symbol end:'overlay'

//=========================================================

//Edge symbol: 'f2'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",733,function(sym,e){sym.stop();});
//Edge binding end
})("f2");
//Edge symbol end:'f2'

//=========================================================

//Edge symbol: 'content'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",800,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2533,function(sym,e){sym.stop();});
//Edge binding end
})("content");
//Edge symbol end:'content'

//=========================================================

//Edge symbol: 'm1'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",733,function(sym,e){sym.stop();});
//Edge binding end
})("m1");
//Edge symbol end:'m1'

//=========================================================

//Edge symbol: 'f1'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",733,function(sym,e){sym.stop();});
//Edge binding end
})("f1");
//Edge symbol end:'f1'

//=========================================================

//Edge symbol: 'glow'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",6000,function(sym,e){sym.play(0);});
//Edge binding end
})("spotlight");
//Edge symbol end:'spotlight'
})})(AdobeEdge.$,AdobeEdge,"EDGE-11294651");